#include <stdio.h>
#include <string.h>
#include <stdlib.h>
// #include <conio.h>

#include "lib.h"

int main (){
	int mask[TAM], maskWrong[TAM], continuar=1, errou=0, acertou=0;
	char *word=NULL, *wrongAnswer=NULL, letter;

	do{

		word = readWordFromFile("./files/forca.txt");

		limpa();
		initMask(mask, strlen(word), 0);
		initMask(maskWrong, TAM, 1);

	    while(contValueMask(mask,TAM,1) != strlen(word) && errou < 6){
	        showForca(errou);
	    	printf("\nDigite uma letra\n");
	        //letter = getchar();
	        scanf(" %c", &letter);
	    	if(updateMask(word, mask, letter) == 0){

				// #1 - PROVA – utilize aqui as funcoes de alocacao dinamica

	    		errou++;
	    	}else{
	    		acertou++;
	    	}
	        limpa();
	    	printf("\nLETRAS ERRADAS\n");
			showWordWithMask(wrongAnswer, maskWrong);
	    	printf("\nLETRAS CERTAS\n");
			showWordWithMask(word, mask);
	    	printf("\n\n");
	    }

		// #2 - PROVA – utilize aqui a funcao de rotacionaConteudo()

		// #3 - PROVA – libere aqui todas as variaveis dinamicas
	   	
        showForca(errou);

	   	errou=0;
	   	acertou=0;

	   	printf("\n\njogadas certas = %i\n", acertou);
	   	printf("jogadas erradas = %i\n", errou);

	   	printf("\nJogar Novamente?\n 0 - nao\n 1- sim\n");
        scanf("%i", &continuar);

	}while(continuar);

    return 0;
}
