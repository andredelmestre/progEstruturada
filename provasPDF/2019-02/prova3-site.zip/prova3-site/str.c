#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

#include "str.h"

void limpa(){
	getchar();
	system("cls|clear\n");
}

void showForca(int erros){
	switch(erros){
		case 1:
			printf("  +---+  \n");
			printf("  |   |  \n");
			printf("  O   |  \n");
			printf("      |  \n");
			printf("      |  \n");
			printf("      |  \n");
			printf("=========\n");
		break;
		case 2:
			printf("  +---+  \n");
			printf("  |   |  \n");
			printf("  O   |  \n");
			printf("  |   |  \n");
			printf("      |  \n");
			printf("      |  \n");
			printf("=========\n");
		break;
		case 3:
			printf("  +---+  \n");
			printf("  |   |  \n");
			printf("  O   |  \n");
			printf(" /|   |  \n");
			printf("      |  \n");
			printf("      |  \n");
			printf("=========\n");
		break;
		case 4:
			printf("  +---+  \n");
			printf("  |   |  \n");
			printf("  O   |  \n");
			printf(" /|\\  |  \n");
			printf("      |  \n");
			printf("      |  \n");
			printf("=========\n");
		break;
		case 5:
			printf("  +---+  \n");
			printf("  |   |  \n");
			printf("  O   |  \n");
			printf(" /|\\  |  \n");
			printf(" /    |  \n");
			printf("      |  \n");
			printf("=========\n");
		break;
		case 6:
			printf("  +---+  \n");
			printf("  |   |  \n");
			printf("  O   |  \n");
			printf(" /|\\  |  \n");
			printf(" / \\  |  \n");
			printf("      |  \n");
			printf("=========\n");
		break;
		default:
			printf("  +---+  \n");
			printf("  |   |  \n");
			printf("      |  \n");
			printf("      |  \n");
			printf("      |  \n");
			printf("      |  \n");
			printf("=========\n");
		break;
	}
	printf("\n\n");
}

void initMask(int * mask, int tam, int value){
	for (int i = 0; i < TAM; ++i){
		*(mask+i) = value;
	}
}

void showWordWithMask(char * word, int * mask){
	printf("  ");
	if(word!=NULL){
		for (int i = 0; i < strlen(word); ++i){
			if(*(mask+i))
				printf("%c", *(word+i));
			else
				printf("_");
			printf("  ");
		}
	}
	printf("\n");
}

int updateMask(char * word, int * mask, char letter){
	int count=0;
	for (int i = 0; i < strlen(word); ++i){
		if(*(word+i)==letter){
			*(mask+i)=!(*(mask+i));
			count++;
		}
	}
	return count;
}

int contValueMask(int * mask, int tam, int value){
	int count=0;
	for (int i = 0; i < tam; ++i){
		if(*(mask+i)==value){
			count++;
		}
	}
	return count;
}

char * readWordFromFile(char * fileName){
	FILE *fp;
	char strStatic[30];
	fp=fopen(fileName, "r");
	if(fp == NULL){
		printf("Erro ao ler arquivo");
		return NULL;
	}
	fgets(strStatic, 30, fp);
	fclose(fp);

	//remove \n
	*(strStatic+strlen(strStatic)-1) = '\0';

	char *str = malloc(strlen(strStatic)*sizeof(char));
	if(str == NULL){
		printf("Erro ao alocar memoria");
		return NULL;
	}
	strcpy(str, strStatic);
	return str;
}
