#ifndef LIB_H_INCLUDED
#define LIB_H_INCLUDED

#include "str.h"

#endif