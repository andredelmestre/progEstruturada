#ifndef STR_H_INCLUDED
#define STR_H_INCLUDED


#define TAM 50

//Gabarito Prova 2
void initMask(int * mask, int tam, int value);
void showWordWithMask(char * word, int * mask);
int updateMask(char * word, int * mask, char letter);
int contValueMask(int * mask, int tam, int value);
void limpa();
void showForca(int erros);


//Funcao nova para Prova 3
char * readWordFromFile(char * fileName);


//Funcoes desenvolvidas pelos alunos

#endif /* STR_H_INCLUDED */